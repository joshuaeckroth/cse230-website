#ifndef MATH_TREE_H
#define MATH_TREE_H

#include <string>

struct tree
{
    std::string op;
    double val;
    tree *left;
    tree *right;
};

extern void print_ascii_tree(tree * t);

#endif

